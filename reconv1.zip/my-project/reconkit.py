#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# ReconKit — Advanced External Attack Surface Reconnaissance Suite
# Author: Ashish
# Environment: Kali Linux / Debian
#

import sys
import os
import re
import ssl
import json
import html
import socket
import shutil
import argparse
import subprocess
import warnings
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
except ImportError:
    requests = None


CLR_RESET  = "\033[0m"
CLR_RED    = "\033[31m"
CLR_GREEN  = "\033[32m"
CLR_CYAN   = "\033[36m"
CLR_BOLD   = "\033[1m"
CLR_YELLOW = "\033[33m"


def show_banner():
    art = f"""{CLR_CYAN}
  ____                      _  ___ _   
 |  _ \\ ___  ___ ___  _ __  | |/ (_) |_ 
 | |_) / _ \\/ __/ _ \\| '_ \\ | ' /| | __|
 |  _ <  __/ (_| (_) | | | || . \\| | |_ 
 |_| \\_\\___|\\___\\___/|_| |_||_|\\_\\_|\\__|{CLR_RESET}
    {CLR_BOLD}ReconKit Enterprise Suite{CLR_RESET} | {CLR_GREEN}Dev: Ashish{CLR_RESET}
    External Attack Surface & Threat Intelligence Mapper
"""
    print(art)


def has_tool(binary):
    return shutil.which(binary) is not None


def exec_shell(cmd_args, timeout=60):
    try:
        proc = subprocess.run(
            cmd_args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout
        )
        return proc.stdout.strip() or proc.stderr.strip()
    except Exception as err:
        return f"[!] Shell error: {err}"


def check_domain_syntax(target):
    regex = r"^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.[A-Za-z0-9-]{1,63}(?<!-))+$"
    return bool(re.match(regex, target))


# --------------------------------------------------------------------------
# Reconnaissance Modules
# --------------------------------------------------------------------------

def do_whois(domain):
    if not has_tool("whois"):
        return {"error": "whois binary missing (apt-get install whois)"}
    
    raw = exec_shell(["whois", domain])
    fields = {}
    
    rules = {
        "Registrar": r"Registrar:\s*(.+)",
        "Creation Date": r"Creation Date:\s*(.+)",
        "Expiration Date": r"Registry Expiry Date:\s*(.+)",
        "Name Servers": r"Name Server:\s*(.+)",
        "Organization": r"Registrant Organization:\s*(.+)"
    }
    
    for tag, pattern in rules.items():
        hits = re.findall(pattern, raw, re.IGNORECASE)
        if hits:
            if tag == "Name Servers":
                fields[tag] = sorted(list(set(h.strip().lower() for h in hits)))
            else:
                fields[tag] = hits[0].strip()
                
    return fields if fields else {"raw_whois": raw[:400]}


def do_asn_lookup(domain):
    """Retrieve ASN, ISP, and BGP network ranges via RDAP/IP metadata."""
    if not requests:
        return {"error": "requests library missing"}
    try:
        ip = socket.gethostbyname(domain)
        r = requests.get(f"https://ipapi.co/{ip}/json/", timeout=10, headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"})
        if r.status_code == 200:
            data = r.json()
            return {
                "ip": ip,
                "asn": data.get("asn", "Unknown"),
                "organization": data.get("org", "Unknown"),
                "network_range": data.get("network", "Unknown"),
                "country": data.get("country_name", "Unknown"),
                "city": data.get("city", "Unknown")
            }
    except Exception as err:
        return {"error": str(err)}
    return {"error": "Unable to resolve ASN data"}


def do_dns_records(domain):
    data = {}
    query_types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"]
    
    if has_tool("dig"):
        for q in query_types:
            res = exec_shell(["dig", "+short", domain, q], timeout=15)
            lines = [l for l in res.splitlines() if l.strip()]
            if lines:
                data[q] = lines
    else:
        try:
            data["A"] = [socket.gethostbyname(domain)]
        except socket.gaierror:
            data["A"] = []
            
    return data


def do_dnssec(domain):
    """Audit DNSSEC validation records."""
    if not has_tool("dig"):
        return {"error": "dig binary required"}
    
    out = exec_shell(["dig", "+dnssec", "+short", domain, "A"], timeout=10)
    has_rrsig = any("RRSIG" in line for line in out.splitlines())
    ds_records = exec_shell(["dig", "+short", domain, "DS"], timeout=10)
    
    enabled = has_rrsig or bool(ds_records.strip())
    return {
        "enabled": enabled,
        "status": "Secured with DNSSEC" if enabled else "Unsigned (No DNSSEC)",
        "ds_record": ds_records.strip() or "None"
    }


def do_caa(domain):
    """Audit Certificate Authority Authorization (CAA)."""
    if not has_tool("dig"):
        return {"error": "dig binary required"}
        
    raw_caa = exec_shell(["dig", "+short", domain, "CAA"], timeout=10)
    lines = [l.strip() for l in raw_caa.splitlines() if l.strip()]
    return {
        "status": "Enforced" if lines else "Missing (Any CA may issue certificates)",
        "records": lines
    }


def do_axfr(domain):
    """Attempt full DNS Zone Transfer across all authoritative nameservers."""
    if not has_tool("dig"):
        return {"error": "dig utility required"}
        
    raw_ns = exec_shell(["dig", "+short", domain, "NS"], timeout=10)
    nameservers = [ns.strip().rstrip(".") for ns in raw_ns.splitlines() if ns.strip()]
    if not nameservers:
        return {"status": "No nameservers identified"}
        
    findings = {}
    for ns in nameservers:
        res = exec_shell(["dig", "axfr", f"@{ns}", domain], timeout=15)
        if "XFR size" in res or ("Transfer failed" not in res and "failed:" not in res and len(res.splitlines()) > 5):
            findings[ns] = "VULNERABLE (Zone transfer allowed)"
        else:
            findings[ns] = "Protected (Refused)"
            
    return findings


def do_waf_detect(domain):
    """Inspect headers and cookies for WAF/reverse proxy signatures."""
    if not requests:
        return {"error": "requests library missing"}
        
    signatures = {
        "Cloudflare": ["__cfduid", "cf-ray", "cloudflare"],
        "AWS CloudFront / WAF": ["x-amz-cf-id", "awselb", "amazon"],
        "Akamai": ["akamai", "x-akamai-transformed"],
        "Imperva / Incapsula": ["incap_ses", "visid_incap", "x-cdn"],
        "Fastly": ["fastly-restarts", "x-fastly"],
        "Sucuri": ["x-sucuri-id", "sucuri"]
    }
    detected = []
    try:
        r = requests.get(f"https://{domain}", timeout=10, headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"})
        payload = (" ".join(r.headers.keys()) + " " + " ".join(r.headers.values()) + " " + " ".join(r.cookies.keys())).lower()

        for waf_name, markers in signatures.items():
            if any(m.lower() in payload for m in markers):
                detected.append(waf_name)
    except requests.RequestException as e:
        return [f"Probe error: {e}"]

    return detected if detected else ["No signature detected"]


def do_crtsh(domain):
    """Passive discovery via Certificate Transparency logs."""
    if not requests:
        return ["requests missing (pip3 install requests)"]
        
    endpoint = f"https://crt.sh/?q=%25.{domain}&output=json"
    discovered = set()
    
    try:
        req = requests.get(endpoint, timeout=25, headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"})
        if req.status_code == 200:
            for item in req.json():
                val = item.get("name_value", "")
                for sub in val.split("\n"):
                    sub = sub.strip().lower().lstrip("*.")
                    if sub.endswith(domain):
                        discovered.add(sub)
            return sorted(list(discovered))
    except Exception as e:
        return [f"crt.sh error: {e}"]
        
    return []


def do_wayback_urls(domain, limit=100):
    """Passively fetch historically archived endpoints from the Wayback Machine."""
    if not requests:
        return ["requests library missing"]
    
    cdx_url = (
        f"https://web.archive.org/cdx/search/cdx"
        f"?url=*.{domain}/*&output=json&collapse=urlkey&fl=original&limit={limit}"
    )
    
    try:
        r = requests.get(
            cdx_url,
            timeout=20,
            headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"}
        )
        if r.status_code == 200:
            data = r.json()
            if len(data) > 1:
                extracted_urls = sorted(list(set(entry[0] for entry in data[1:] if entry)))
                return extracted_urls
        return []
    except Exception as err:
        return [f"Wayback lookup failed: {err}"]


def do_sub_brute(domain, wordlist_file, threads=25):
    """Active DNS resolution brute-force."""
    if not os.path.exists(wordlist_file):
        return [{"error": f"Wordlist not found: {wordlist_file}"}]
        
    with open(wordlist_file, "r", encoding="utf-8", errors="ignore") as f:
        words = [w.strip() for w in f if w.strip()]
        
    live_hosts = []
    
    def resolve_sub(w):
        fqdn = f"{w}.{domain}"
        try:
            ip = socket.gethostbyname(fqdn)
            return {"host": fqdn, "ip": ip}
        except socket.gaierror:
            return None
            
    with ThreadPoolExecutor(max_workers=threads) as pool:
        jobs = {pool.submit(resolve_sub, word): word for word in words}
        for task in as_completed(jobs):
            res = task.result()
            if res:
                live_hosts.append(res)
                
    return sorted(live_hosts, key=lambda x: x["host"])


def do_takeover_check(subdomains):
    """Inspect subdomains for dangling cloud provider CNAME fingerprints."""
    if not requests or not subdomains:
        return []
        
    fingerprints = {
        "GitHub Pages": "There isn't a GitHub Pages site here",
        "AWS S3": "The specified bucket does not exist",
        "Heroku": "No such app",
        "Shopify": "Sorry, this shop is currently unavailable"
    }
    vulnerable = []

    def probe(sub):
        try:
            r = requests.get(f"http://{sub}", timeout=5, headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"})
            for provider, sig in fingerprints.items():
                if sig in r.text:
                    return {"subdomain": sub, "provider": provider, "risk": "High (Dangling Resource)"}
        except requests.RequestException:
            pass
        return None

    with ThreadPoolExecutor(max_workers=20) as pool:
        futures = [pool.submit(probe, s) for s in subdomains[:35] if isinstance(s, str)]
        for f in as_completed(futures):
            res = f.result()
            if res:
                vulnerable.append(res)

    return vulnerable


def do_nmap(domain, port_range="1-1000"):
    if not has_tool("nmap"):
        return {"error": "nmap binary missing (apt-get install nmap)"}
        
    cmd = ["nmap", "-Pn", "-sV", "-T4", "-p", port_range, domain]
    output = exec_shell(cmd, timeout=360)
    
    result = {"ip": None, "ports": []}
    
    ip_lookup = re.search(r"for\s+(?:[^\s]+\s+)?\(?([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})\)?", output)
    if ip_lookup:
        result["ip"] = ip_lookup.group(1)
        
    line_re = r"^(\d+/(?:tcp|udp))\s+(\w+)\s+(\S+)\s*(.*)$"
    for line in output.splitlines():
        match = re.match(line_re, line.strip())
        if match:
            result["ports"].append({
                "port": match.group(1),
                "state": match.group(2),
                "service": match.group(3),
                "version": match.group(4).strip() or "-"
            })
            
    return result


def do_http_probe(domain):
    if not requests:
        return {"error": "requests library missing"}
        
    results = {}
    for proto in ["https", "http"]:
        url = f"{proto}://{domain}"
        try:
            r = requests.get(url, timeout=8, allow_redirects=True, headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"})
            results[proto] = {
                "code": r.status_code,
                "server": r.headers.get("Server", "-"),
                "powered_by": r.headers.get("X-Powered-By", "-"),
                "destination": r.url
            }
        except requests.RequestException:
            results[proto] = {"status": "unreachable"}
            
    return results


def do_sec_headers(domain):
    if not requests:
        return {"error": "requests library missing"}
        
    watchlist = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
        "Permissions-Policy"
    ]
    
    summary = {"passed": {}, "missing": []}
    try:
        resp = requests.get(f"https://{domain}", timeout=10, headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"})
        for h in watchlist:
            if h in resp.headers:
                summary["passed"][h] = resp.headers[h]
            else:
                summary["missing"].append(h)
    except Exception as e:
        return {"error": str(e)}
        
    return summary


def do_cert_grab(domain):
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((domain, 443), timeout=10) as s:
            with ctx.wrap_socket(s, server_hostname=domain) as ssl_sock:
                cert = ssl_sock.getpeercert()
                
        sub_dict = dict(x[0] for x in cert.get("subject", []))
        iss_dict = dict(x[0] for x in cert.get("issuer", []))
        alt_names = [v for k, v in cert.get("subjectAltName", []) if k == "DNS"]
        
        return {
            "cn": sub_dict.get("commonName", "-"),
            "issuer": iss_dict.get("organizationName", iss_dict.get("commonName", "Unknown")),
            "valid_from": cert.get("notBefore", "-"),
            "valid_until": cert.get("notAfter", "-"),
            "sans_count": len(alt_names),
            "sans_sample": alt_names[:8]
        }
    except Exception as err:
        return {"error": str(err)}


def do_tls_audit(domain):
    """Enumerate supported TLS protocol versions without triggering DeprecationWarnings."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        
        protocols = {
            "TLSv1.0": getattr(ssl.TLSVersion, "TLSv1", None),
            "TLSv1.1": getattr(ssl.TLSVersion, "TLSv1_1", None),
            "TLSv1.2": getattr(ssl.TLSVersion, "TLSv1_2", None),
            "TLSv1.3": getattr(ssl.TLSVersion, "TLSv1_3", None),
        }
        
        results = {}
        for proto_name, proto_const in protocols.items():
            if proto_const is None:
                results[proto_name] = {"supported": False, "note": "Unsupported by local OpenSSL"}
                continue
            try:
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                ctx.minimum_version = proto_const
                ctx.maximum_version = proto_const
                
                with socket.create_connection((domain, 443), timeout=5) as sock:
                    with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                        cipher = ssock.cipher()
                        results[proto_name] = {
                            "supported": True,
                            "cipher": cipher[0] if cipher else "Unknown"
                        }
            except (ssl.SSLError, socket.error, TimeoutError, OSError):
                results[proto_name] = {"supported": False}
                
        return results


def do_email_sec(domain):
    out = {"spf": "None", "dmarc": "None"}
    if has_tool("dig"):
        raw_spf = exec_shell(["dig", "+short", domain, "TXT"], timeout=10)
        for line in raw_spf.splitlines():
            if "v=spf1" in line:
                out["spf"] = line.strip('"')
                break
                
        raw_dmarc = exec_shell(["dig", "+short", f"_dmarc.{domain}", "TXT"], timeout=10)
        for line in raw_dmarc.splitlines():
            if "v=DMARC1" in line:
                out["dmarc"] = line.strip('"')
                break
    else:
        out["_warn"] = "dig utility required"
    return out


def do_metadata_files(domain):
    if not requests:
        return {"error": "requests missing"}
        
    targets = {
        "robots.txt": f"https://{domain}/robots.txt",
        "security.txt": f"https://{domain}/.well-known/security.txt"
    }
    dump = {}
    
    for fname, uri in targets.items():
        try:
            res = requests.get(uri, timeout=6, headers={"User-Agent": "Mozilla/5.0 (ReconKit-Ashish)"})
            if res.status_code == 200 and "text" in res.headers.get("Content-Type", ""):
                lines = [l.strip() for l in res.text.splitlines() if l.strip() and not l.startswith("#")]
                dump[fname] = {
                    "found": True,
                    "count": len(lines),
                    "snippet": lines[:5]
                }
            else:
                dump[fname] = {"found": False, "code": res.status_code}
        except requests.RequestException:
            dump[fname] = {"found": False, "status": "down"}
            
    return dump


def calculate_score(report_data):
    """Compute overall defensive hardening score (0-100)."""
    score = 100
    deductions = []
    
    mail = report_data.get("email_hardening", {})
    if mail.get("spf") in ["None", "Not configured"]:
        score -= 15
        deductions.append("Missing SPF record (-15)")
    if mail.get("dmarc") in ["None", "Not configured"]:
        score -= 15
        deductions.append("Missing DMARC policy (-15)")
        
    sec_h = report_data.get("security_headers", {})
    missing = sec_h.get("missing", [])
    if "Content-Security-Policy" in missing:
        score -= 15
        deductions.append("Missing Content-Security-Policy (-15)")
    if "Strict-Transport-Security" in missing:
        score -= 15
        deductions.append("Missing Strict-Transport-Security (-15)")
    if "X-Frame-Options" in missing:
        score -= 10
        deductions.append("Missing X-Frame-Options (-10)")
        
    dnssec = report_data.get("dnssec", {})
    if not dnssec.get("enabled", False):
        score -= 10
        deductions.append("DNSSEC not enabled (-10)")

    score = max(0, score)
    grade = "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 55 else "D" if score >= 40 else "F"
    
    return {
        "score": f"{score}/100",
        "grade": grade,
        "findings": deductions or ["All hardening baselines satisfied"]
    }


# --------------------------------------------------------------------------
# Terminal Output Formatter
# --------------------------------------------------------------------------

def print_cli_summary(report):
    print(f"\n{CLR_BOLD}{'='*75}{CLR_RESET}")
    print(f" {CLR_GREEN}[*]{CLR_RESET} Target Assessment: {CLR_BOLD}{report['target']}{CLR_RESET}")
    print(f" {CLR_GREEN}[*]{CLR_RESET} Scan Time (UTC):   {report['timestamp']}")
    print(f" {CLR_GREEN}[*]{CLR_RESET} Analyst / Dev:     Ashish")
    if "score" in report:
        print(f" {CLR_GREEN}[*]{CLR_RESET} Hardening Grade:   {CLR_BOLD}{report['score']['grade']} ({report['score']['score']}){CLR_RESET}")
    print(f"{CLR_BOLD}{'='*75}{CLR_RESET}")

    if "asn" in report and "asn" in report["asn"]:
        print(f"\n{CLR_CYAN}[+] Infrastructure & BGP ASN{CLR_RESET}")
        a = report["asn"]
        print(f"  ASN          : {a.get('asn')} ({a.get('organization')})")
        print(f"  Network CIDR : {a.get('network_range')}")
        print(f"  Location     : {a.get('city')}, {a.get('country')}")

    if "waf" in report:
        print(f"\n{CLR_CYAN}[+] WAF / Reverse Proxy{CLR_RESET}")
        print(f"  Signatures   : {', '.join(report['waf'])}")

    if "whois" in report and isinstance(report["whois"], dict):
        print(f"\n{CLR_CYAN}[+] WHOIS Records{CLR_RESET}")
        for k, v in report["whois"].items():
            if isinstance(v, list):
                print(f"  {k:<18} : {v[0]}")
                for item in v[1:]:
                    print(f"  {'':<18}   {item}")
            else:
                print(f"  {k:<18} : {v}")

    if "dns" in report and isinstance(report["dns"], dict):
        print(f"\n{CLR_CYAN}[+] DNS Zone Records{CLR_RESET}")
        for qtype, recs in report["dns"].items():
            print(f"  {qtype:<8} -> {recs[0]}")
            for r in recs[1:]:
                print(f"  {'':<8}    {r}")

    if "dnssec" in report:
        print(f"\n{CLR_CYAN}[+] DNSSEC Deployment{CLR_RESET}")
        print(f"  Status       : {report['dnssec'].get('status')}")

    if "caa" in report:
        print(f"\n{CLR_CYAN}[+] Certificate Authority Authorization (CAA){CLR_RESET}")
        print(f"  Status       : {report['caa'].get('status')}")

    if "axfr" in report:
        print(f"\n{CLR_CYAN}[+] DNS Zone Transfer (AXFR){CLR_RESET}")
        for ns, res in report["axfr"].items():
            print(f"  {ns:<25} : {res}")

    if "ssl" in report and "issuer" in report["ssl"]:
        print(f"\n{CLR_CYAN}[+] TLS/SSL Certificate{CLR_RESET}")
        s = report["ssl"]
        print(f"  Common Name  : {s.get('cn')}")
        print(f"  Issuer       : {s.get('issuer')}")
        print(f"  Expiration   : {s.get('valid_until')}")
        print(f"  SANs Total   : {s.get('sans_count')} (e.g. {', '.join(s.get('sans_sample', []))})")

    if "tls_audit" in report:
        print(f"\n{CLR_CYAN}[+] Supported TLS Protocols{CLR_RESET}")
        for proto, meta in report["tls_audit"].items():
            state = f"{CLR_GREEN}Supported{CLR_RESET} ({meta.get('cipher')})" if meta.get("supported") else f"{CLR_RED}Disabled{CLR_RESET}"
            print(f"  {proto:<10} : {state}")

    if "email_hardening" in report:
        print(f"\n{CLR_CYAN}[+] Email Spoofing Defense (SPF/DMARC){CLR_RESET}")
        print(f"  SPF          : {report['email_hardening'].get('spf')}")
        print(f"  DMARC        : {report['email_hardening'].get('dmarc')}")

    if "security_headers" in report and "missing" in report["security_headers"]:
        print(f"\n{CLR_CYAN}[+] Web Security Headers{CLR_RESET}")
        sh = report["security_headers"]
        print(f"  Active  ({len(sh['passed'])}): {', '.join(sh['passed'].keys()) or 'None'}")
        print(f"  Missing ({len(sh['missing'])}): {', '.join(sh['missing']) or 'None'}")

    if "http_endpoints" in report:
        print(f"\n{CLR_CYAN}[+] Web Endpoints{CLR_RESET}")
        print(f"  {'SCHEME':<8} {'CODE':<6} {'SERVER':<22} {'POWERED BY':<16} {'FINAL URL'}")
        print(f"  {'-'*6:<8} {'-'*4:<6} {'-'*20:<22} {'-'*14:<16} {'-'*20}")
        for proto, info in report["http_endpoints"].items():
            if info.get("status") == "unreachable":
                print(f"  {proto.upper():<8} {'DOWN':<6} {'-':<22} {'-':<16} -")
            else:
                print(f"  {proto.upper():<8} {str(info.get('code','-')):<6} {info.get('server','-')[:20]:<22} {info.get('powered_by','-')[:14]:<16} {info.get('destination','-')}")

    if "nmap" in report and "ports" in report["nmap"]:
        host_ip = report["nmap"].get("ip") or "Unknown"
        print(f"\n{CLR_CYAN}[+] Open Ports (Nmap Host: {host_ip}){CLR_RESET}")
        ports = report["nmap"]["ports"]
        if not ports:
            print("  No open ports found.")
        else:
            print(f"  {'PORT':<12} {'STATE':<10} {'SERVICE':<15} {'BANNER'}")
            print(f"  {'-'*10:<12} {'-'*8:<10} {'-'*13:<15} {'-'*25}")
            for p in ports:
                print(f"  {p['port']:<12} {p['state']:<10} {p['service']:<15} {p['version']}")

    if "wayback_urls" in report and isinstance(report["wayback_urls"], list):
        print(f"\n{CLR_CYAN}[+] Archived Endpoints (Wayback Machine: {len(report['wayback_urls'])}){CLR_RESET}")
        wb = report["wayback_urls"]
        for u in wb[:8]:
            print(f"  * {u}")
        if len(wb) > 8:
            print(f"  ... (+ {len(wb) - 8} more in report files)")

    if "takeovers" in report and report["takeovers"]:
        print(f"\n{CLR_RED}[!] High Risk: Subdomain Takeover Vulnerabilities{CLR_RESET}")
        for t in report["takeovers"]:
            print(f"  Target: {t.get('subdomain')} -> Service: {t.get('provider')}")

    if "metadata_files" in report:
        print(f"\n{CLR_CYAN}[+] Public Disclosure Files{CLR_RESET}")
        for file_key, meta in report["metadata_files"].items():
            status = "FOUND" if meta.get("found") else "NOT FOUND"
            print(f"  {file_key:<16} : {status}")

    if "crtsh_subdomains" in report:
        print(f"\n{CLR_CYAN}[+] Passive Subdomains (crt.sh: {len(report['crtsh_subdomains'])}){CLR_RESET}")
        subs = report["crtsh_subdomains"]
        for item in subs[:8]:
            print(f"  - {item}")
        if len(subs) > 8:
            print(f"  ... (+ {len(subs)-8} more recorded in report)")

    print(f"\n{CLR_BOLD}{'='*75}{CLR_RESET}\n")


# --------------------------------------------------------------------------
# HTML Dashboard Generator
# --------------------------------------------------------------------------

def export_html(report, out_file):
    domain = html.escape(str(report.get("target", "")))
    date = html.escape(str(report.get("timestamp", "")))
    
    score_data = report.get("score", {"grade": "N/A", "score": "N/A", "findings": []})
    grade = str(score_data.get("grade", "N/A"))
    score_val = str(score_data.get("score", "N/A"))
    
    grade_color = "#22c55e" if grade in ["A", "B"] else "#eab308" if grade == "C" else "#ef4444"
    if grade == "N/A":
        grade_color = "#64748b"

    asn_info = report.get("asn", {}) if isinstance(report.get("asn"), dict) else {}
    nmap_info = report.get("nmap", {}) if isinstance(report.get("nmap"), dict) else {}
    ports = nmap_info.get("ports", [])
    waf_list = report.get("waf", ["None"])
    subs = report.get("crtsh_subdomains", [])
    wayback = report.get("wayback_urls", [])

    body = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ReconKit Assessment — {domain}</title>
<style>
  :root {{
    --bg-main: #090d16;
    --bg-card: #111827;
    --bg-card-hover: #172033;
    --border-color: #1f293d;
    --border-glow: #38bdf822;
    --accent: #38bdf8;
    --text-main: #f1f5f9;
    --text-muted: #94a3b8;
    --danger: #ef4444;
    --success: #22c55e;
    --warning: #f59e0b;
  }}

  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    background-color: var(--bg-main);
    color: var(--text-main);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    line-height: 1.5;
    padding: 32px 20px;
  }}

  .wrapper {{ max-width: 1240px; margin: 0 auto; }}

  /* Header */
  .header {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: linear-gradient(135deg, #111827 0%, #0f172a 100%);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 24px 32px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.4);
  }}
  .header-title h1 {{
    font-size: 1.8rem;
    font-weight: 700;
    color: #fff;
    letter-spacing: -0.5px;
  }}
  .header-title h1 span {{ color: var(--accent); }}
  .header-meta {{
    font-size: 0.88rem;
    color: var(--text-muted);
    margin-top: 6px;
  }}

  /* Score Pill */
  .score-badge-container {{
    display: flex;
    align-items: center;
    gap: 16px;
    background: rgba(15, 23, 42, 0.6);
    border: 1px solid var(--border-color);
    padding: 12px 20px;
    border-radius: 10px;
  }}
  .grade-circle {{
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: {grade_color}22;
    color: {grade_color};
    border: 2px solid {grade_color};
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    font-weight: 800;
  }}
  .grade-text {{ font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted); }}
  .grade-val {{ font-size: 1.1rem; font-weight: 700; color: #fff; }}

  /* Metric KPI Cards */
  .metrics-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
  }}
  .metric-card {{
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    padding: 18px 20px;
  }}
  .metric-label {{
    font-size: 0.78rem;
    text-transform: uppercase;
    color: var(--text-muted);
    font-weight: 600;
    letter-spacing: 0.5px;
  }}
  .metric-value {{
    font-size: 1.35rem;
    font-weight: 700;
    margin-top: 6px;
    color: #fff;
    word-break: break-word;
  }}

  /* Main Grid */
  .grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(580px, 1fr));
    gap: 20px;
    margin-bottom: 24px;
  }}
  @media (max-width: 768px) {{
    .grid {{ grid-template-columns: 1fr; }}
    .header {{ flex-direction: column; align-items: flex-start; gap: 16px; }}
  }}

  /* Panels */
  .panel {{
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 22px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  }}
  .panel-header {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--border-color);
    padding-bottom: 12px;
    margin-bottom: 16px;
  }}
  .panel-title {{
    font-size: 1.05rem;
    font-weight: 600;
    color: var(--accent);
    display: flex;
    align-items: center;
    gap: 8px;
  }}

  /* Tables */
  table {{
    width: 100%;
    border-collapse: collapse;
    font-size: 0.88rem;
  }}
  th, td {{
    padding: 9px 12px;
    text-align: left;
    border-bottom: 1px solid #1e293b;
    vertical-align: top;
  }}
  th {{
    color: var(--text-muted);
    font-weight: 500;
    width: 32%;
  }}
  td {{ color: #e2e8f0; }}

  /* Badges & Tags */
  .badge {{
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.3px;
  }}
  .b-ok {{ background: rgba(34, 197, 94, 0.15); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.3); }}
  .b-err {{ background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }}
  .b-info {{ background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); }}

  /* Searchable Container */
  .search-input {{
    background: #090d16;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    color: #fff;
    font-size: 0.8rem;
    padding: 6px 12px;
    outline: none;
    width: 180px;
    transition: border-color 0.2s;
  }}
  .search-input:focus {{ border-color: var(--accent); }}

  .scroll-box {{
    background: #090d16;
    border: 1px solid #1e293b;
    border-radius: 8px;
    padding: 14px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 0.82rem;
    max-height: 250px;
    overflow-y: auto;
    word-break: break-all;
    line-height: 1.6;
  }}
  .scroll-box a {{ color: var(--accent); text-decoration: none; }}
  .scroll-box a:hover {{ text-decoration: underline; }}
</style>
</head>
<body>

<div class="wrapper">
  <!-- Header -->
  <div class="header">
    <div class="header-title">
      <h1>ReconKit Target Audit: <span>{domain}</span></h1>
      <div class="header-meta">Audited by: <strong>Ashish</strong> &bull; Generated: {date} (UTC)</div>
    </div>
    <div class="score-badge-container">
      <div class="grade-circle">{html.escape(grade)}</div>
      <div>
        <div class="grade-text">Hardening Score</div>
        <div class="grade-val">{html.escape(score_val)}</div>
      </div>
    </div>
  </div>

  <!-- Metric KPIs -->
  <div class="metrics-grid">
    <div class="metric-card">
      <div class="metric-label">Primary IP Address</div>
      <div class="metric-value">{html.escape(str(asn_info.get("ip", nmap_info.get("ip", "Pending"))))}</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">Autonomous System</div>
      <div class="metric-value" style="font-size: 1.1rem;">{html.escape(str(asn_info.get("asn", "Unknown")))}</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">WAF / Edge CDN</div>
      <div class="metric-value" style="font-size: 1.1rem;">{html.escape(waf_list[0] if waf_list else "None")}</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">Open Ports Identified</div>
      <div class="metric-value">{len(ports)}</div>
    </div>
    <div class="metric-card">
      <div class="metric-label">Subdomains Discovered</div>
      <div class="metric-value">{len(subs)}</div>
    </div>
  </div>

  <!-- Security Hardening Findings Panel -->
  <div class="panel" style="margin-bottom: 24px;">
    <div class="panel-header">
      <div class="panel-title">🛡️ Defensive Hardening Evaluation</div>
    </div>
    <table>
      <thead>
        <tr><th>Control Target</th><th>Identified Hardening Status</th></tr>
      </thead>
      <tbody>
        <tr>
          <th>Email Phishing Defense</th>
          <td>
            <strong>SPF:</strong> {html.escape(str(report.get("email_hardening", {}).get("spf", "None")))}<br>
            <strong>DMARC:</strong> {html.escape(str(report.get("email_hardening", {}).get("dmarc", "None")))}
          </td>
        </tr>
        <tr>
          <th>DNSSEC Validation</th>
          <td>
            <span class="badge {'b-ok' if report.get('dnssec',{}).get('enabled') else 'b-err'}">
              {html.escape(str(report.get("dnssec", {}).get("status", "Unchecked")))}
            </span>
          </td>
        </tr>
        <tr>
          <th>Certificate Authority Restriction (CAA)</th>
          <td>{html.escape(str(report.get("caa", {}).get("status", "Unchecked")))}</td>
        </tr>
        <tr>
          <th>Deductions / Audit Findings</th>
          <td>
"""
    for finding in score_data.get("findings", []):
        badge_type = "b-ok" if "passed" in finding.lower() or "satisfied" in finding.lower() else "b-err"
        body += f"<span class='badge {badge_type}' style='margin: 2px 4px;'>{html.escape(finding)}</span> "

    body += """
          </td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Main Layout Grid -->
  <div class="grid">
"""

    # Infrastructure & Network
    if asn_info:
        body += f"""
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">🌐 Infrastructure & Routing</div>
      </div>
      <table>
        <tr><th>Resolved IP</th><td>{html.escape(str(asn_info.get('ip','-')))}</td></tr>
        <tr><th>BGP ASN</th><td>{html.escape(str(asn_info.get('asn','-')))}</td></tr>
        <tr><th>Organization</th><td>{html.escape(str(asn_info.get('organization','-')))}</td></tr>
        <tr><th>Allocated CIDR</th><td><code>{html.escape(str(asn_info.get('network_range','-')))}</code></td></tr>
        <tr><th>Physical Location</th><td>{html.escape(str(asn_info.get('city','-')))}, {html.escape(str(asn_info.get('country','-')))}</td></tr>
      </table>
    </div>
"""

    # WHOIS
    if "whois" in report and isinstance(report["whois"], dict):
        body += """
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">📋 Domain Registration (WHOIS)</div>
      </div>
      <table>
"""
        for k, v in report["whois"].items():
            val = "<br>".join(html.escape(str(x)) for x in v) if isinstance(v, list) else html.escape(str(v))
            body += f"<tr><th>{html.escape(k)}</th><td>{val}</td></tr>"
        body += "</table></div>"

    # DNS Zone Records
    if "dns" in report and isinstance(report["dns"], dict):
        body += """
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">📡 DNS Zone Records</div>
      </div>
      <table>
"""
        for qt, recs in report["dns"].items():
            body += f"<tr><th>{html.escape(qt)}</th><td>{'<br>'.join(html.escape(r) for r in recs)}</td></tr>"
        body += "</table></div>"

    # TLS Certificate
    if "ssl" in report and isinstance(report["ssl"], dict):
        cert = report["ssl"]
        body += f"""
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">🔒 SSL/TLS Certificate</div>
      </div>
      <table>
        <tr><th>Common Name (CN)</th><td>{html.escape(str(cert.get('cn','-')))}</td></tr>
        <tr><th>Certificate Issuer</th><td>{html.escape(str(cert.get('issuer','-')))}</td></tr>
        <tr><th>Expiration Date</th><td>{html.escape(str(cert.get('valid_until','-')))}</td></tr>
        <tr><th>SANs Count</th><td><span class="badge b-info">{html.escape(str(cert.get('sans_count',0)))} Names</span></td></tr>
      </table>
    </div>
"""

    # HTTP Security Headers
    if "security_headers" in report and isinstance(report["security_headers"], dict):
        sh = report["security_headers"]
        body += """
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">🛡️ Defensive HTTP Headers</div>
      </div>
      <table>
        <tr><th>Configured</th><td>
"""
        for k in sh.get("passed", {}):
            body += f"<span class='badge b-ok' style='margin:2px;'>{html.escape(k)}</span> "
        body += """
        </td></tr>
        <tr><th>Missing</th><td>
"""
        for k in sh.get("missing", []):
            body += f"<span class='badge b-err' style='margin:2px;'>{html.escape(k)}</span> "
        body += """
        </td></tr>
      </table>
    </div>
"""

    # Zone Transfer (AXFR)
    if "axfr" in report and isinstance(report["axfr"], dict):
        body += """
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">🔄 DNS Zone Transfer (AXFR)</div>
      </div>
      <table>
"""
        for ns, res in report["axfr"].items():
            badge_cls = "b-err" if "VULNERABLE" in res else "b-ok"
            body += f"<tr><th>{html.escape(ns)}</th><td><span class='badge {badge_cls}'>{html.escape(res)}</span></td></tr>"
        body += "</table></div>"

    body += "</div>"  # End of 2-column grid

    # Discovered Ports (Full Width)
    if ports:
        body += f"""
  <div class="panel" style="margin-bottom: 24px;">
    <div class="panel-header">
      <div class="panel-title">🚪 Open Ports & Services ({len(ports)})</div>
      <input type="text" id="portSearch" class="search-input" placeholder="Filter ports/services..." onkeyup="filterTable('portSearch', 'portsTable')">
    </div>
    <table id="portsTable">
      <thead>
        <tr><th>Port</th><th>State</th><th>Service</th><th>Version Banner</th></tr>
      </thead>
      <tbody>
"""
        for p in ports:
            body += f"""
        <tr>
          <td><strong>{html.escape(p['port'])}</strong></td>
          <td><span class="badge b-ok">{html.escape(p['state'])}</span></td>
          <td>{html.escape(p['service'])}</td>
          <td><code>{html.escape(p['version'])}</code></td>
        </tr>
"""
        body += "</tbody></table></div>"

    # Bottom Grid: Subdomains and Historical URLs
    body += '<div class="grid">'

    if subs:
        body += f"""
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">🎯 Subdomains ({len(subs)})</div>
        <input type="text" id="subSearch" class="search-input" placeholder="Search subdomains..." onkeyup="filterList('subSearch', 'subList')">
      </div>
      <div class="scroll-box" id="subList">
"""
        for s in subs:
            body += f"<div class='filter-item'>{html.escape(s)}</div>"
        body += "</div></div>"

    if wayback:
        body += f"""
    <div class="panel">
      <div class="panel-header">
        <div class="panel-title">🕰️ Wayback Archive Endpoints ({len(wayback)})</div>
        <input type="text" id="wbSearch" class="search-input" placeholder="Filter URLs..." onkeyup="filterList('wbSearch', 'wbList')">
      </div>
      <div class="scroll-box" id="wbList">
"""
        for u in wayback:
            body += f"<div class='filter-item'><a href='{html.escape(u)}' target='_blank' rel='noopener'>{html.escape(u)}</a></div>"
        body += "</div></div>"

    body += """
  </div>
</div>

<script>
function filterTable(inputId, tableId) {
  const input = document.getElementById(inputId);
  const filter = input.value.toLowerCase();
  const rows = document.getElementById(tableId).getElementsByTagName('tr');
  for (let i = 1; i < rows.length; i++) {
    const text = rows[i].textContent || rows[i].innerText;
    rows[i].style.display = text.toLowerCase().indexOf(filter) > -1 ? "" : "none";
  }
}

function filterList(inputId, containerId) {
  const input = document.getElementById(inputId);
  const filter = input.value.toLowerCase();
  const items = document.getElementById(containerId).getElementsByClassName('filter-item');
  for (let i = 0; i < items.length; i++) {
    const text = items[i].textContent || items[i].innerText;
    items[i].style.display = text.toLowerCase().indexOf(filter) > -1 ? "" : "none";
  }
}
</script>
</body>
</html>"""

    with open(out_file, "w", encoding="utf-8") as f:
        f.write(body)


# --------------------------------------------------------------------------
# CLI Argument Parsing & Orchestration
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="ReconKit — Advanced Attack Surface Reconnaissance (By Ashish)")
    parser.add_argument("domain", help="Target domain name (e.g. site.com)")
    parser.add_argument("--whois", action="store_true", help="Perform WHOIS query")
    parser.add_argument("--dns", action="store_true", help="Run DNS zone checks")
    parser.add_argument("--asn", action="store_true", help="Resolve BGP ASN and network CIDR")
    parser.add_argument("--waf", action="store_true", help="Fingerprint Web Application Firewall")
    parser.add_argument("--axfr", action="store_true", help="Attempt DNS Zone Transfer across nameservers")
    parser.add_argument("--dnssec", action="store_true", help="Audit DNSSEC validation")
    parser.add_argument("--caa", action="store_true", help="Audit Certificate Authority Authorization (CAA)")
    parser.add_argument("--subdomains", action="store_true", help="Passive CT log subdomains (crt.sh)")
    parser.add_argument("--wayback", action="store_true", help="Harvest historical URLs from the Wayback Machine")
    parser.add_argument("--wordlist", help="Wordlist path for active DNS brute-force")
    parser.add_argument("--takeover-check", action="store_true", help="Audit subdomains for dangling cloud services")
    parser.add_argument("--ports", help="Ports to scan via Nmap (default: 1-1000)")
    parser.add_argument("--http", action="store_true", help="Check HTTP server fingerprint")
    parser.add_argument("--sec-headers", action="store_true", help="Inspect web security headers")
    parser.add_argument("--ssl", action="store_true", help="Inspect SSL/TLS certificate")
    parser.add_argument("--tls-audit", action="store_true", help="Enumerate supported TLS protocol versions")
    parser.add_argument("--mail", action="store_true", help="Query SPF and DMARC records")
    parser.add_argument("--meta", action="store_true", help="Probe robots.txt and security.txt")
    parser.add_argument("--score", action="store_true", help="Calculate hardening posture grade")
    parser.add_argument("--all", action="store_true", help="Execute complete recon suite")
    parser.add_argument("--i-have-authorization", action="store_true", help="Confirm testing authorization")
    args = parser.parse_args()

    show_banner()

    target = args.domain.strip().lower()
    if not check_domain_syntax(target):
        print(f"{CLR_RED}[!] Malformed domain name: {target}{CLR_RESET}")
        sys.exit(1)

    if not args.i_have_authorization:
        print(f"{CLR_RED}[!] Authorization flag required: pass --i-have-authorization to proceed.{CLR_RESET}")
        sys.exit(1)

    base_dir = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(base_dir, "reports")
    os.makedirs(out_dir, exist_ok=True)

    json_path = os.path.join(out_dir, f"{target}_report.json")
    html_path = os.path.join(out_dir, f"{target}_report.html")

    report_data = {
        "target": target,
        "author": "Ashish",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

    # Module Execution Flow
    if args.whois or args.all:
        report_data["whois"] = do_whois(target)
    if args.asn or args.all:
        report_data["asn"] = do_asn_lookup(target)
    if args.waf or args.all:
        report_data["waf"] = do_waf_detect(target)
    if args.dns or args.all:
        report_data["dns"] = do_dns_records(target)
    if args.dnssec or args.all:
        report_data["dnssec"] = do_dnssec(target)
    if args.caa or args.all:
        report_data["caa"] = do_caa(target)
    if args.axfr or args.all:
        report_data["axfr"] = do_axfr(target)
    if args.ssl or args.all:
        report_data["ssl"] = do_cert_grab(target)
    if args.tls_audit or args.all:
        report_data["tls_audit"] = do_tls_audit(target)
    if args.mail or args.all:
        report_data["email_hardening"] = do_email_sec(target)
    if args.sec_headers or args.all:
        report_data["security_headers"] = do_sec_headers(target)
    if args.http or args.all:
        report_data["http_endpoints"] = do_http_probe(target)
    if args.meta or args.all:
        report_data["metadata_files"] = do_metadata_files(target)
    if args.wayback or args.all:
        report_data["wayback_urls"] = do_wayback_urls(target)
    if args.ports or args.all:
        report_data["nmap"] = do_nmap(target, args.ports or "1-1000")
        
    subs = []
    if args.subdomains or args.all:
        subs = do_crtsh(target)
        report_data["crtsh_subdomains"] = subs
    if args.wordlist:
        brute_subs = do_sub_brute(target, args.wordlist)
        report_data["active_subdomains"] = brute_subs
        subs.extend([b["host"] for b in brute_subs if isinstance(b, dict) and "host" in b])

    if args.takeover_check or args.all:
        report_data["takeovers"] = do_takeover_check(list(set(subs)))

    if args.score or args.all:
        report_data["score"] = calculate_score(report_data)

    print_cli_summary(report_data)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(report_data, f, indent=2, default=str)

    export_html(report_data, html_path)

    print(f"{CLR_GREEN}[+] Success: Output saved in 'reports/' folder:{CLR_RESET}")
    print(f"    - JSON : {json_path}")
    print(f"    - HTML : {html_path}\n")


if __name__ == "__main__":
    main()